#!/bin/sh
java -jar ConnectedLap.jar
